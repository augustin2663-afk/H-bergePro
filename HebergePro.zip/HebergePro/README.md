# HebergePro — hébergement de sites web statiques

Basé sur le module « Website Hosting » de FileShare Pro (PHP + SQLite), refait en français et sécurisé.

## Lancer en local
    php -S localhost:8000 router.php
puis ouvrir http://localhost:8000 (PHP 8.1+ avec extensions sqlite3 et zip).

## Hébergement réel (Apache)
Copier le dossier sur le serveur. Les dossiers `data/` (base SQLite) et `sites/` (fichiers des sites) sont
protégés par `.htaccess`. Sur Nginx, ajouter :
    location ~ ^/(data|sites)/ { deny all; }
Les sites sont servis par `site.php/{nom}/`. Les dossiers `data/` et `sites/` doivent être accessibles en écriture par PHP.
Pensez à activer HTTPS et à régler `upload_max_filesize` / `post_max_size` (≥ 50M) dans php.ini.

## Réglages (config.php)
Quotas (sites par compte, taille max), extensions bloquées.

## Sécurité
- Mots de passe hachés, sessions régénérées, jetons CSRF, limitation des tentatives de connexion
- ZIP : protection zip-slip, limite de taille/nombre de fichiers, fichiers .php/.htaccess ignorés
- Les sites sont servis avec `Content-Security-Policy: sandbox` : leur JavaScript ne peut pas accéder à la session de la plateforme
- Aucun code serveur des utilisateurs n'est exécuté (sites statiques uniquement)
