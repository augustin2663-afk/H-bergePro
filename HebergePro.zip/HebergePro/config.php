<?php
// ===== Configuration HebergePro =====
define('APP_NAME', 'HebergePro');
define('DB_FILE', __DIR__ . '/data/database.db');
define('SITES_DIR', __DIR__ . '/sites');

// Quotas par utilisateur
define('MAX_SITES_PER_USER', 5);
define('MAX_UPLOAD_SIZE', 50 * 1024 * 1024);        // taille max d'un envoi (50 Mo)
define('MAX_SITE_SIZE', 100 * 1024 * 1024);         // taille max décompressée d'un site (100 Mo)
define('MAX_ZIP_FILES', 2000);                      // nombre max de fichiers dans un zip

// Extensions interdites (code exécutable côté serveur)
const BLOCKED_EXT = ['php','php3','php4','php5','php7','php8','phtml','phar','pht','phps','cgi','pl','py','sh','exe','htaccess','htpasswd','ini'];
// Extensions modifiables dans l'éditeur
const EDITABLE_EXT = ['html','htm','css','js','json','txt','md','svg','xml'];

const MIME_TYPES = [
    'html'=>'text/html; charset=UTF-8','htm'=>'text/html; charset=UTF-8','css'=>'text/css; charset=UTF-8',
    'js'=>'application/javascript; charset=UTF-8','mjs'=>'application/javascript; charset=UTF-8',
    'json'=>'application/json; charset=UTF-8','txt'=>'text/plain; charset=UTF-8','md'=>'text/plain; charset=UTF-8',
    'xml'=>'application/xml; charset=UTF-8','svg'=>'image/svg+xml','png'=>'image/png','jpg'=>'image/jpeg',
    'jpeg'=>'image/jpeg','gif'=>'image/gif','webp'=>'image/webp','avif'=>'image/avif','ico'=>'image/x-icon',
    'woff'=>'font/woff','woff2'=>'font/woff2','ttf'=>'font/ttf','otf'=>'font/otf','mp4'=>'video/mp4',
    'webm'=>'video/webm','mp3'=>'audio/mpeg','wav'=>'audio/wav','ogg'=>'audio/ogg','pdf'=>'application/pdf',
    'wasm'=>'application/wasm','map'=>'application/json',
];

function getDB(): SQLite3 {
    static $db = null;
    if ($db) return $db;
    $new = !file_exists(DB_FILE);
    $db = new SQLite3(DB_FILE);
    $db->busyTimeout(5000);
    $db->exec('PRAGMA foreign_keys = ON');
    if ($new) initDatabase($db);
    return $db;
}

function initDatabase(SQLite3 $db): void {
    $db->exec("CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE NOT NULL,
        email TEXT UNIQUE NOT NULL,
        password TEXT NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        last_login DATETIME
    )");
    $db->exec("CREATE TABLE IF NOT EXISTS websites (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        site_name TEXT UNIQUE NOT NULL,
        views INTEGER DEFAULT 0,
        size INTEGER DEFAULT 0,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id)
    )");
}

// ---------- Session & auth ----------
function startSecureSession(): void {
    if (session_status() === PHP_SESSION_NONE) {
        $https = !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off';
        session_set_cookie_params(['lifetime'=>0,'path'=>'/','secure'=>$https,'httponly'=>true,'samesite'=>'Lax']);
        session_start();
    }
}
function isLoggedIn(): bool { startSecureSession(); return isset($_SESSION['user_id'], $_SESSION['username']); }
function getCurrentUserId(): ?int { return $_SESSION['user_id'] ?? null; }
function getCurrentUsername(): ?string { return $_SESSION['username'] ?? null; }
function requireLogin(): void { if (!isLoggedIn()) { header('Location: login.php'); exit; } }

// ---------- CSRF ----------
function csrfToken(): string {
    startSecureSession();
    if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(32));
    return $_SESSION['csrf'];
}
function csrfField(): string { return '<input type="hidden" name="csrf" value="' . csrfToken() . '">'; }
function checkCsrf(): bool {
    startSecureSession();
    return isset($_POST['csrf'], $_SESSION['csrf']) && hash_equals($_SESSION['csrf'], $_POST['csrf']);
}

// ---------- Utilitaires ----------
function e($s): string { return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }

function formatFileSize($bytes): string {
    $bytes = max((int)$bytes, 0);
    if ($bytes === 0) return '0 o';
    $units = ['o', 'Ko', 'Mo', 'Go'];
    $pow = min((int)floor(log($bytes, 1024)), 3);
    return round($bytes / pow(1024, $pow), $pow ? 1 : 0) . ' ' . $units[$pow];
}

function getBaseUrl(): string {
    $https = !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off';
    $dir = rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'])), '/');
    return ($https ? 'https' : 'http') . '://' . ($_SERVER['HTTP_HOST'] ?? 'localhost') . $dir;
}
function siteUrl(string $name): string { return getBaseUrl() . '/site.php/' . rawurlencode($name) . '/'; }

function normalizeSiteName(string $n): string {
    return trim(preg_replace('/[^a-z0-9-]/', '', strtolower($n)), '-');
}
const RESERVED_NAMES = ['www','admin','api','site','assets','data','login','register','dashboard','mail','ftp'];

function sitePath(string $name): string { return SITES_DIR . '/' . $name; }

function dirSize(string $dir): int {
    $t = 0;
    if (!is_dir($dir)) return 0;
    $it = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($dir, FilesystemIterator::SKIP_DOTS));
    foreach ($it as $f) if ($f->isFile()) $t += $f->getSize();
    return $t;
}

function deleteDirectory(string $dir): void {
    if (!is_dir($dir)) return;
    foreach (array_diff(scandir($dir), ['.', '..']) as $f) {
        $p = "$dir/$f";
        (is_dir($p) && !is_link($p)) ? deleteDirectory($p) : unlink($p);
    }
    rmdir($dir);
}

function isBlockedFile(string $path): bool {
    $base = strtolower(basename($path));
    if (str_starts_with($base, '.ht')) return true;
    foreach (explode('.', $base) as $i => $part) {            // ex: shell.php.jpg
        if ($i > 0 && in_array($part, BLOCKED_EXT, true)) return true;
    }
    return false;
}

/** Extrait un zip en toute sécurité. Retourne null si OK, sinon un message d'erreur. */
function safeExtractZip(string $zipFile, string $dest): ?string {
    $zip = new ZipArchive();
    if ($zip->open($zipFile) !== true) return "Archive ZIP invalide.";
    if ($zip->numFiles > MAX_ZIP_FILES) { $zip->close(); return "Trop de fichiers dans l'archive (max " . MAX_ZIP_FILES . ")."; }

    // Détecte un dossier racine unique (ex: monsite/index.html) pour l'aplatir
    $names = [];
    for ($i = 0; $i < $zip->numFiles; $i++) {
        $n = str_replace('\\', '/', $zip->getNameIndex($i));
        if (str_starts_with($n, '__MACOSX/') || basename($n) === '.DS_Store') continue;
        if (str_contains($n, '..') || str_starts_with($n, '/') || preg_match('/^[a-zA-Z]:/', $n) || str_contains($n, "\0")) continue; // zip-slip
        $names[] = $n;
    }
    $strip = '';
    $roots = array_unique(array_map(fn($n) => explode('/', $n)[0], $names));
    if (count($roots) === 1 && !in_array($roots[0], $names, true) && !in_array('index.html', $names, true)) $strip = $roots[0] . '/';

    $total = 0;
    foreach ($names as $n) {
        $idx = $zip->locateName($n);
        $st = $zip->statIndex($idx);
        $total += $st['size'];
        if ($total > MAX_SITE_SIZE) { $zip->close(); return "Le site dépasse " . formatFileSize(MAX_SITE_SIZE) . " une fois décompressé."; }
    }
    foreach ($names as $n) {
        $rel = ($strip && str_starts_with($n, $strip)) ? substr($n, strlen($strip)) : $n;
        if ($rel === '' ) continue;
        if (str_contains($rel, '..') || str_starts_with($rel, '/') || preg_match('/^[a-zA-Z]:/', $rel) || str_contains($rel, "\0")) continue; // zip-slip
        $target = $dest . '/' . $rel;
        if (str_ends_with($rel, '/')) { @mkdir($target, 0755, true); continue; }
        if (isBlockedFile($rel)) continue;                    // fichiers exécutables ignorés
        @mkdir(dirname($target), 0755, true);
        $in = $zip->getStream($zip->getNameIndex($zip->locateName($n)));
        if (!$in) continue;
        $out = fopen($target, 'wb');
        stream_copy_to_stream($in, $out);
        fclose($in); fclose($out);
    }
    $zip->close();
    return null;
}

function getUserSite(int $id, int $uid): ?array {
    $st = getDB()->prepare('SELECT * FROM websites WHERE id = :id AND user_id = :u');
    $st->bindValue(':id', $id, SQLITE3_INTEGER);
    $st->bindValue(':u', $uid, SQLITE3_INTEGER);
    $r = $st->execute()->fetchArray(SQLITE3_ASSOC);
    return $r ?: null;
}

// ---------- Mise en page ----------
function pageHeader(string $title, string $active = '', bool $app = true): void {
    startSecureSession();
    $logged = isLoggedIn();
    echo '<!DOCTYPE html><html lang="fr"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1">';
    echo '<title>' . e($title) . ' · ' . APP_NAME . '</title><link rel="stylesheet" href="assets/style.css"></head><body>';
    echo '<header class="nav"><div class="wrap nav-in"><a class="logo" href="index.php"><span class="logo-mark">⬢</span>' . APP_NAME . '</a><nav>';
    if ($logged) {
        echo '<a href="dashboard.php"' . ($active === 'dashboard' ? ' class="on"' : '') . '>Mes sites</a>';
        echo '<a href="deploy.php"' . ($active === 'deploy' ? ' class="on"' : '') . '>Déployer</a>';
        echo '<span class="user">👤 ' . e(getCurrentUsername()) . '</span><a class="btn btn-ghost btn-sm" href="logout.php">Déconnexion</a>';
    } else {
        echo '<a href="index.php#features">Fonctionnalités</a><a href="index.php#how">Comment ça marche</a><a href="login.php">Connexion</a><a class="btn btn-sm" href="register.php">Créer un compte</a>';
    }
    echo '</nav></div></header>';
}
function pageFooter(): void {
    echo '<footer class="foot"><div class="wrap">© ' . date('Y') . ' ' . APP_NAME . ' — Hébergement de sites web statiques</div></footer></body></html>';
}
