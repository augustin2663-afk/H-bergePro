<?php
require_once 'config.php';
requireLogin();
$db = getDB(); $uid = getCurrentUserId(); $msg = ''; $type = 'success';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'delete') {
    if (!checkCsrf()) { $msg = 'Session expirée.'; $type = 'error'; }
    elseif ($site = getUserSite((int)($_POST['site_id'] ?? 0), $uid)) {
        deleteDirectory(sitePath($site['site_name']));
        $st = $db->prepare('DELETE FROM websites WHERE id = :i'); $st->bindValue(':i', $site['id'], SQLITE3_INTEGER); $st->execute();
        $msg = 'Site « ' . $site['site_name'] . ' » supprimé.';
    }
}
if (isset($_GET['msg'])) $msg = $_GET['msg'] === 'created' ? 'Votre site est en ligne !' : ($_GET['msg'] === 'saved' ? 'Modifications enregistrées.' : '');

$st = $db->prepare('SELECT * FROM websites WHERE user_id = :u ORDER BY created_at DESC'); $st->bindValue(':u', $uid, SQLITE3_INTEGER);
$r = $st->execute(); $sites = [];
while ($row = $r->fetchArray(SQLITE3_ASSOC)) $sites[] = $row;
$views = array_sum(array_column($sites, 'views')); $size = array_sum(array_column($sites, 'size'));

pageHeader('Mes sites', 'dashboard');
?>
<main class="page"><div class="wrap">
  <div class="page-head"><h1>Mes sites</h1>
    <?php if (count($sites) < MAX_SITES_PER_USER): ?><a class="btn" href="deploy.php">+ Nouveau site</a><?php endif; ?></div>
  <?php if ($msg): ?><div class="alert alert-<?= $type ?>"><?= e($msg) ?></div><?php endif; ?>
  <div class="kpis">
    <div class="card kpi"><div class="v"><?= count($sites) ?> / <?= MAX_SITES_PER_USER ?></div><div class="l">Sites utilisés</div></div>
    <div class="card kpi"><div class="v"><?= $views ?></div><div class="l">Visites totales</div></div>
    <div class="card kpi"><div class="v"><?= formatFileSize($size) ?></div><div class="l">Espace utilisé</div></div>
  </div>
  <?php if (!$sites): ?>
    <div class="card empty"><div class="ic">🌐</div><p><b>Aucun site pour l'instant.</b></p><p style="margin-bottom:18px">Déployez votre premier site en quelques secondes.</p><a class="btn" href="deploy.php">Déployer un site</a></div>
  <?php endif; foreach ($sites as $s): $url = siteUrl($s['site_name']); ?>
    <div class="card site">
      <div><h3><?= e($s['site_name']) ?><span class="badge">● En ligne</span></h3>
        <div class="url"><a href="<?= e($url) ?>" target="_blank" rel="noopener"><?= e($url) ?></a></div>
        <div class="meta"><?= (int)$s['views'] ?> visites · <?= formatFileSize($s['size']) ?> · créé le <?= date('d/m/Y', strtotime($s['created_at'])) ?></div></div>
      <div class="actions">
        <a class="btn btn-sm" href="<?= e($url) ?>" target="_blank" rel="noopener">Visiter</a>
        <a class="btn btn-sm btn-ghost" href="edit.php?id=<?= (int)$s['id'] ?>">Gérer</a>
        <button class="btn btn-sm btn-ghost" onclick="navigator.clipboard.writeText('<?= e($url) ?>');this.textContent='Copié ✓'">Copier le lien</button>
        <form method="POST" onsubmit="return confirm('Supprimer définitivement ce site ?')"><?= csrfField() ?>
          <input type="hidden" name="action" value="delete"><input type="hidden" name="site_id" value="<?= (int)$s['id'] ?>">
          <button class="btn btn-sm btn-danger">Supprimer</button></form>
      </div>
    </div>
  <?php endforeach; ?>
</div></main>
<?php pageFooter();
