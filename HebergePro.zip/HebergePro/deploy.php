<?php
require_once 'config.php';
requireLogin();
$db = getDB(); $uid = getCurrentUserId(); $error = '';

$cnt = $db->prepare('SELECT COUNT(*) FROM websites WHERE user_id = :u'); $cnt->bindValue(':u', $uid, SQLITE3_INTEGER);
$count = (int)$cnt->execute()->fetchArray()[0];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = normalizeSiteName($_POST['site_name'] ?? '');
    $code = $_POST['html_code'] ?? '';
    $hasFile = isset($_FILES['website_file']) && $_FILES['website_file']['error'] !== UPLOAD_ERR_NO_FILE;
    if (!checkCsrf()) $error = 'Session expirée, rechargez la page.';
    elseif ($count >= MAX_SITES_PER_USER) $error = 'Limite de ' . MAX_SITES_PER_USER . ' sites atteinte.';
    elseif (strlen($name) < 3 || strlen($name) > 40) $error = 'Le nom doit contenir entre 3 et 40 caractères (a-z, 0-9, tirets).';
    elseif (in_array($name, RESERVED_NAMES, true)) $error = 'Ce nom est réservé.';
    elseif (!$hasFile && trim($code) === '') $error = 'Ajoutez un fichier ou du code HTML.';
    else {
        $st = $db->prepare('SELECT 1 FROM websites WHERE site_name = :n'); $st->bindValue(':n', $name);
        if ($st->execute()->fetchArray()) $error = 'Ce nom est déjà pris, choisissez-en un autre.';
        else {
            $dir = sitePath($name);
            mkdir($dir, 0755, true);
            if ($hasFile) {
                $f = $_FILES['website_file'];
                $ext = strtolower(pathinfo($f['name'], PATHINFO_EXTENSION));
                if ($f['error'] !== UPLOAD_ERR_OK || $f['size'] > MAX_UPLOAD_SIZE) $error = 'Échec de l\'envoi (max ' . formatFileSize(MAX_UPLOAD_SIZE) . ').';
                elseif ($ext === 'zip') $error = safeExtractZip($f['tmp_name'], $dir) ?? '';
                elseif (in_array($ext, ['html', 'htm'], true)) move_uploaded_file($f['tmp_name'], "$dir/index.html");
                else $error = 'Format accepté : ZIP, HTML ou HTM.';
            } else {
                file_put_contents("$dir/index.html", $code);
            }
            if (!$error && !is_file("$dir/index.html") && !is_file("$dir/index.htm")) $error = "Aucun fichier index.html trouvé à la racine de votre site.";
            if ($error) deleteDirectory($dir);
            else {
                $size = dirSize($dir);
                $st = $db->prepare('INSERT INTO websites (user_id, site_name, size) VALUES (:u,:n,:s)');
                $st->bindValue(':u', $uid, SQLITE3_INTEGER); $st->bindValue(':n', $name); $st->bindValue(':s', $size, SQLITE3_INTEGER);
                $st->execute();
                header('Location: dashboard.php?msg=created'); exit;
            }
        }
    }
}
$tab = (isset($_POST['html_code']) && trim($_POST['html_code']) !== '') ? 'code' : 'file';
$template = "<!DOCTYPE html>\n<html lang=\"fr\">\n<head>\n  <meta charset=\"UTF-8\">\n  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">\n  <title>Mon site</title>\n  <style>body{font-family:sans-serif;text-align:center;padding:80px 20px}</style>\n</head>\n<body>\n  <h1>Bonjour le monde 👋</h1>\n  <p>Mon premier site hébergé sur " . APP_NAME . ".</p>\n</body>\n</html>";
pageHeader('Déployer un site', 'deploy');
?>
<main class="page"><div class="wrap" style="max-width:820px">
  <div class="page-head"><h1>Déployer un site</h1><a class="btn btn-ghost btn-sm" href="dashboard.php">← Mes sites</a></div>
  <?php if ($error): ?><div class="alert alert-error"><?= e($error) ?></div><?php endif; ?>
  <?php if ($count >= MAX_SITES_PER_USER): ?><div class="alert alert-error">Vous avez atteint la limite de <?= MAX_SITES_PER_USER ?> sites. Supprimez-en un pour continuer.</div><?php else: ?>
  <div class="card">
    <div class="tabs">
      <button type="button" class="tab <?= $tab === 'file' ? 'on' : '' ?>" data-t="file">📁 Envoyer un fichier</button>
      <button type="button" class="tab <?= $tab === 'code' ? 'on' : '' ?>" data-t="code">💻 Éditeur de code</button>
    </div>
    <form method="POST" enctype="multipart/form-data"><?= csrfField() ?>
      <div class="form-group"><label>Nom du site</label>
        <div class="sitebox"><span>site.php/</span><input type="text" name="site_name" value="<?= e($_POST['site_name'] ?? '') ?>" placeholder="mon-super-site" pattern="[a-zA-Z0-9\-]{3,40}" required></div>
        <small>Lettres minuscules, chiffres et tirets (3 à 40 caractères).</small></div>
      <div class="pane <?= $tab === 'file' ? 'on' : '' ?>" id="p-file">
        <div class="form-group"><label>Fichier ZIP ou HTML</label>
          <div class="drop" id="drop"><input type="file" name="website_file" id="file" accept=".zip,.html,.htm"><p class="hint" style="margin-top:10px">Le ZIP doit contenir un <b>index.html</b> à la racine. Max <?= formatFileSize(MAX_UPLOAD_SIZE) ?>.<br>Les fichiers serveur (.php, etc.) sont ignorés : seuls les sites statiques sont hébergés.</p></div></div>
      </div>
      <div class="pane <?= $tab === 'code' ? 'on' : '' ?>" id="p-code">
        <div class="form-group"><label>Code HTML</label><textarea class="code" name="html_code" spellcheck="false"><?= e($_POST['html_code'] ?? $template) ?></textarea></div>
      </div>
      <button class="btn">🚀 Publier le site</button>
    </form>
  </div>
  <?php endif; ?>
</div></main>
<script>
const tabs=document.querySelectorAll('.tab'),file=document.getElementById('file'),code=document.querySelector('textarea[name=html_code]');
function sw(t){tabs.forEach(b=>b.classList.toggle('on',b.dataset.t===t));document.getElementById('p-file').classList.toggle('on',t==='file');document.getElementById('p-code').classList.toggle('on',t==='code');
  if(t==='file'){code.disabled=true}else{code.disabled=false;file.value=''}}
tabs.forEach(b=>b.onclick=()=>sw(b.dataset.t));sw(document.querySelector('.tab.on').dataset.t);
const d=document.getElementById('drop');['dragover','dragenter'].forEach(e=>d.addEventListener(e,ev=>{ev.preventDefault();d.classList.add('over')}));
['dragleave','drop'].forEach(e=>d.addEventListener(e,()=>d.classList.remove('over')));
d.addEventListener('drop',ev=>{ev.preventDefault();file.files=ev.dataTransfer.files});
code.addEventListener('keydown',e=>{if(e.key==='Tab'){e.preventDefault();const s=code.selectionStart;code.setRangeText('  ',s,code.selectionEnd,'end')}});
</script>
<?php pageFooter();
