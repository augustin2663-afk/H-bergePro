<?php
require_once 'config.php';
requireLogin();
$db = getDB(); $uid = getCurrentUserId();
$site = getUserSite((int)($_GET['id'] ?? $_POST['id'] ?? 0), $uid);
if (!$site) { header('Location: dashboard.php'); exit; }
$root = sitePath($site['site_name']); $msg = ''; $type = 'success';

/** Résout un chemin relatif dans le site, sans sortir du dossier. */
function resolveIn(string $root, string $rel): ?string {
    $rel = ltrim(str_replace('\\', '/', $rel), '/');
    if ($rel === '' || str_contains($rel, "\0")) return null;
    $full = realpath($root . '/' . $rel);
    $r = realpath($root);
    return ($full && $r && str_starts_with($full, $r . DIRECTORY_SEPARATOR) && is_file($full)) ? $full : null;
}
function refreshSize(SQLite3 $db, array $site, string $root): void {
    $st = $db->prepare("UPDATE websites SET size = :s, updated_at = CURRENT_TIMESTAMP WHERE id = :i");
    $st->bindValue(':s', dirSize($root), SQLITE3_INTEGER); $st->bindValue(':i', $site['id'], SQLITE3_INTEGER); $st->execute();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $act = $_POST['action'] ?? '';
    if (!checkCsrf()) { $msg = 'Session expirée.'; $type = 'error'; }
    elseif ($act === 'save') {
        $f = resolveIn($root, $_POST['file'] ?? '');
        $ext = $f ? strtolower(pathinfo($f, PATHINFO_EXTENSION)) : '';
        if (!$f || !in_array($ext, EDITABLE_EXT, true)) { $msg = 'Fichier non modifiable.'; $type = 'error'; }
        elseif (strlen($_POST['content'] ?? '') > 5 * 1024 * 1024) { $msg = 'Fichier trop volumineux.'; $type = 'error'; }
        else { file_put_contents($f, $_POST['content'] ?? ''); refreshSize($db, $site, $root); $msg = 'Fichier enregistré.'; }
    } elseif ($act === 'delfile') {
        $f = resolveIn($root, $_POST['file'] ?? '');
        if ($f && basename($f) !== 'index.html') { unlink($f); refreshSize($db, $site, $root); $msg = 'Fichier supprimé.'; }
        else { $msg = 'Impossible de supprimer ce fichier.'; $type = 'error'; }
    } elseif ($act === 'replace') {
        $fl = $_FILES['website_file'] ?? null;
        if (!$fl || $fl['error'] !== UPLOAD_ERR_OK || $fl['size'] > MAX_UPLOAD_SIZE) { $msg = "Échec de l'envoi."; $type = 'error'; }
        else {
            $ext = strtolower(pathinfo($fl['name'], PATHINFO_EXTENSION)); $tmp = $root . '_new_' . bin2hex(random_bytes(4));
            mkdir($tmp, 0755, true); $err = null;
            if ($ext === 'zip') $err = safeExtractZip($fl['tmp_name'], $tmp);
            elseif (in_array($ext, ['html','htm'], true)) move_uploaded_file($fl['tmp_name'], "$tmp/index.html");
            else $err = 'Format accepté : ZIP, HTML ou HTM.';
            if (!$err && !is_file("$tmp/index.html") && !is_file("$tmp/index.htm")) $err = 'Aucun index.html trouvé à la racine.';
            if ($err) { deleteDirectory($tmp); $msg = $err; $type = 'error'; }
            else { deleteDirectory($root); rename($tmp, $root); refreshSize($db, $site, $root); $msg = 'Site mis à jour.'; }
        }
    }
}

// Liste des fichiers
$files = [];
if (is_dir($root)) {
    $it = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($root, FilesystemIterator::SKIP_DOTS));
    foreach ($it as $fi) if ($fi->isFile()) $files[] = ['rel' => str_replace('\\', '/', substr($fi->getPathname(), strlen($root) + 1)), 'size' => $fi->getSize()];
    usort($files, fn($a, $b) => strcmp($a['rel'], $b['rel']));
}
$cur = $_GET['file'] ?? $_POST['file'] ?? '';
$curPath = $cur ? resolveIn($root, $cur) : null;
$curEditable = $curPath && in_array(strtolower(pathinfo($curPath, PATHINFO_EXTENSION)), EDITABLE_EXT, true);
$url = siteUrl($site['site_name']);
pageHeader('Gérer ' . $site['site_name'], 'dashboard');
?>
<main class="page"><div class="wrap">
  <div class="page-head"><div><h1><?= e($site['site_name']) ?></h1><a href="<?= e($url) ?>" target="_blank" rel="noopener"><?= e($url) ?></a></div>
    <a class="btn btn-ghost btn-sm" href="dashboard.php">← Mes sites</a></div>
  <?php if ($msg): ?><div class="alert alert-<?= $type ?>"><?= e($msg) ?></div><?php endif; ?>

  <?php if ($curEditable): ?>
  <div class="card" style="margin-bottom:22px">
    <h3 style="margin-bottom:14px">✏️ <?= e($cur) ?></h3>
    <form method="POST"><?= csrfField() ?><input type="hidden" name="action" value="save"><input type="hidden" name="id" value="<?= (int)$site['id'] ?>"><input type="hidden" name="file" value="<?= e($cur) ?>">
      <div class="form-group"><textarea class="code" name="content" spellcheck="false"><?= e(file_get_contents($curPath)) ?></textarea></div>
      <button class="btn">Enregistrer</button> <a class="btn btn-ghost" href="edit.php?id=<?= (int)$site['id'] ?>">Fermer</a>
    </form>
  </div>
  <?php endif; ?>

  <div class="card" style="margin-bottom:22px">
    <h3 style="margin-bottom:12px">📁 Fichiers (<?= count($files) ?>)</h3>
    <table class="files"><tr><th>Fichier</th><th>Taille</th><th></th></tr>
    <?php foreach ($files as $f): $ed = in_array(strtolower(pathinfo($f['rel'], PATHINFO_EXTENSION)), EDITABLE_EXT, true); ?>
      <tr><td><?= e($f['rel']) ?></td><td><?= formatFileSize($f['size']) ?></td>
      <td class="actions" style="justify-content:flex-end">
        <?php if ($ed): ?><a class="btn btn-sm btn-ghost" href="edit.php?id=<?= (int)$site['id'] ?>&file=<?= urlencode($f['rel']) ?>">Modifier</a><?php endif; ?>
        <?php if ($f['rel'] !== 'index.html'): ?><form method="POST" onsubmit="return confirm('Supprimer ce fichier ?')"><?= csrfField() ?><input type="hidden" name="action" value="delfile"><input type="hidden" name="id" value="<?= (int)$site['id'] ?>"><input type="hidden" name="file" value="<?= e($f['rel']) ?>"><button class="btn btn-sm btn-danger">×</button></form><?php endif; ?>
      </td></tr>
    <?php endforeach; ?></table>
  </div>

  <div class="card">
    <h3 style="margin-bottom:6px">🔄 Remplacer le site</h3>
    <p class="hint" style="margin-bottom:14px">Envoyez un nouveau ZIP ou fichier HTML : l'ancien contenu sera entièrement remplacé.</p>
    <form method="POST" enctype="multipart/form-data" onsubmit="return confirm('Remplacer tout le contenu du site ?')"><?= csrfField() ?><input type="hidden" name="action" value="replace"><input type="hidden" name="id" value="<?= (int)$site['id'] ?>">
      <div class="form-group"><input type="file" name="website_file" accept=".zip,.html,.htm" required></div><button class="btn">Mettre à jour</button></form>
  </div>
</div></main>
<?php pageFooter();
