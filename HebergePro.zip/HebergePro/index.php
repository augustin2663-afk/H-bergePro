<?php
require_once 'config.php';
$db = getDB();
$nbSites = (int)$db->querySingle('SELECT COUNT(*) FROM websites');
$nbUsers = (int)$db->querySingle('SELECT COUNT(*) FROM users');
pageHeader('Hébergement de sites web');
?>
<main>
<section class="hero"><div class="wrap">
  <h1>Mettez votre site en ligne en quelques secondes</h1>
  <p>Glissez votre dossier ZIP ou collez votre code HTML : votre site est publié instantanément avec sa propre adresse.</p>
  <a class="btn" href="<?= isLoggedIn() ? 'deploy.php' : 'register.php' ?>">Héberger mon site gratuitement</a>
  <?php if (!isLoggedIn()): ?><a class="btn btn-ghost" href="login.php">Connexion</a><?php endif; ?>
  <div class="stats-band">
    <div><b><?= $nbSites ?></b><span>sites hébergés</span></div>
    <div><b><?= $nbUsers ?></b><span>utilisateurs</span></div>
    <div><b><?= MAX_SITES_PER_USER ?></b><span>sites gratuits / compte</span></div>
  </div>
</div></section>

<section class="section" id="features"><div class="wrap">
  <h2>Tout ce qu'il faut pour publier</h2><p class="sub">Simple, rapide, sans configuration serveur.</p>
  <div class="grid">
    <div class="card feat"><div class="ic">📦</div><h3>Envoi par ZIP</h3><p>Déposez une archive : elle est décompressée et publiée automatiquement, dossiers et images inclus.</p></div>
    <div class="card feat"><div class="ic">💻</div><h3>Éditeur intégré</h3><p>Écrivez ou modifiez votre HTML, CSS et JavaScript directement dans le navigateur.</p></div>
    <div class="card feat"><div class="ic">🔗</div><h3>Adresse dédiée</h3><p>Chaque site obtient son propre lien à partager, sans rien installer.</p></div>
    <div class="card feat"><div class="ic">📊</div><h3>Statistiques</h3><p>Suivez le nombre de visites et l'espace utilisé depuis votre tableau de bord.</p></div>
    <div class="card feat"><div class="ic">🔒</div><h3>Sécurisé</h3><p>Sites isolés, archives vérifiées, scripts serveur bloqués et protection CSRF.</p></div>
    <div class="card feat"><div class="ic">⚡</div><h3>Instantané</h3><p>Mise à jour en un clic : remplacez vos fichiers et le changement est immédiat.</p></div>
  </div>
</div></section>

<section class="section" id="how" style="background:#fff"><div class="wrap">
  <h2>Comment ça marche</h2><p class="sub">Trois étapes, moins d'une minute.</p>
  <div class="grid steps">
    <div class="card"><h3>Créez un compte</h3><p class="hint">Inscription gratuite avec email et mot de passe.</p></div>
    <div class="card"><h3>Déposez votre site</h3><p class="hint">ZIP, fichier HTML unique, ou code collé dans l'éditeur.</p></div>
    <div class="card"><h3>Partagez le lien</h3><p class="hint">Votre site est en ligne immédiatement.</p></div>
  </div>
</div></section>

<section class="section"><div class="wrap"><div class="cta">
  <h2>Prêt à publier ?</h2><p>Créez votre premier site maintenant.</p>
  <a class="btn" href="<?= isLoggedIn() ? 'deploy.php' : 'register.php' ?>">Commencer</a>
</div></div></section>
</main>
<?php pageFooter();
