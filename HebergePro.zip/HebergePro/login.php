<?php
require_once 'config.php';
startSecureSession();
if (isLoggedIn()) { header('Location: dashboard.php'); exit; }
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $u = trim($_POST['username'] ?? ''); $p = $_POST['password'] ?? '';
    // Limitation simple des tentatives
    $_SESSION['tries'] = $_SESSION['tries'] ?? 0;
    if (!checkCsrf()) $error = 'Session expirée, rechargez la page.';
    elseif ($_SESSION['tries'] >= 8 && time() - ($_SESSION['last_try'] ?? 0) < 300) $error = 'Trop de tentatives. Réessayez dans quelques minutes.';
    elseif (!$u || !$p) $error = 'Veuillez remplir tous les champs.';
    else {
        $st = getDB()->prepare('SELECT id,username,password FROM users WHERE username = :u OR email = :u');
        $st->bindValue(':u', $u);
        $user = $st->execute()->fetchArray(SQLITE3_ASSOC);
        if ($user && password_verify($p, $user['password'])) {
            session_regenerate_id(true);
            $_SESSION['user_id'] = $user['id']; $_SESSION['username'] = $user['username']; $_SESSION['tries'] = 0;
            $up = getDB()->prepare('UPDATE users SET last_login = CURRENT_TIMESTAMP WHERE id = :i');
            $up->bindValue(':i', $user['id'], SQLITE3_INTEGER); $up->execute();
            header('Location: dashboard.php'); exit;
        }
        $_SESSION['tries']++; $_SESSION['last_try'] = time();
        $error = 'Identifiants incorrects.';
    }
}
pageHeader('Connexion');
?>
<main class="auth"><div class="card">
  <h1>Connexion</h1><p class="lead">Accédez à vos sites.</p>
  <?php if ($error): ?><div class="alert alert-error"><?= e($error) ?></div><?php endif; ?>
  <form method="POST"><?= csrfField() ?>
    <div class="form-group"><label>Nom d'utilisateur ou email</label><input type="text" name="username" value="<?= e($_POST['username'] ?? '') ?>" required autofocus></div>
    <div class="form-group"><label>Mot de passe</label><input type="password" name="password" required></div>
    <button class="btn btn-block">Se connecter</button>
  </form>
  <p class="alt">Pas encore de compte ? <a href="register.php">S'inscrire</a></p>
</div></main>
<?php pageFooter();
