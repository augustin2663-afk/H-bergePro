<?php
require_once 'config.php';
startSecureSession();
if (isLoggedIn()) { header('Location: dashboard.php'); exit; }
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $u = trim($_POST['username'] ?? ''); $m = trim($_POST['email'] ?? '');
    $p = $_POST['password'] ?? ''; $c = $_POST['confirm_password'] ?? '';
    if (!checkCsrf()) $error = 'Session expirée, rechargez la page.';
    elseif (!$u || !$m || !$p || !$c) $error = 'Veuillez remplir tous les champs.';
    elseif (!preg_match('/^[A-Za-z0-9_.-]{3,30}$/', $u)) $error = "Nom d'utilisateur : 3 à 30 caractères (lettres, chiffres, _ . -).";
    elseif (!filter_var($m, FILTER_VALIDATE_EMAIL)) $error = 'Adresse email invalide.';
    elseif (strlen($p) < 8) $error = 'Le mot de passe doit contenir au moins 8 caractères.';
    elseif ($p !== $c) $error = 'Les mots de passe ne correspondent pas.';
    else {
        $db = getDB();
        $st = $db->prepare('SELECT 1 FROM users WHERE username = :u OR email = :m');
        $st->bindValue(':u', $u); $st->bindValue(':m', $m);
        if ($st->execute()->fetchArray()) $error = "Ce nom d'utilisateur ou cet email est déjà utilisé.";
        else {
            $st = $db->prepare('INSERT INTO users (username,email,password) VALUES (:u,:m,:p)');
            $st->bindValue(':u', $u); $st->bindValue(':m', $m); $st->bindValue(':p', password_hash($p, PASSWORD_DEFAULT));
            $st->execute();
            session_regenerate_id(true);
            $_SESSION['user_id'] = $db->lastInsertRowID(); $_SESSION['username'] = $u;
            header('Location: deploy.php'); exit;
        }
    }
}
pageHeader('Inscription');
?>
<main class="auth"><div class="card">
  <h1>Créer un compte</h1><p class="lead">Gratuit, sans carte bancaire.</p>
  <?php if ($error): ?><div class="alert alert-error"><?= e($error) ?></div><?php endif; ?>
  <form method="POST"><?= csrfField() ?>
    <div class="form-group"><label>Nom d'utilisateur</label><input type="text" name="username" value="<?= e($_POST['username'] ?? '') ?>" required autofocus></div>
    <div class="form-group"><label>Email</label><input type="email" name="email" value="<?= e($_POST['email'] ?? '') ?>" required></div>
    <div class="form-group"><label>Mot de passe</label><input type="password" name="password" minlength="8" required><small>8 caractères minimum</small></div>
    <div class="form-group"><label>Confirmer le mot de passe</label><input type="password" name="confirm_password" required></div>
    <button class="btn btn-block">Créer mon compte</button>
  </form>
  <p class="alt">Déjà inscrit ? <a href="login.php">Se connecter</a></p>
</div></main>
<?php pageFooter();
