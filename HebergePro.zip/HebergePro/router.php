<?php
// Routeur pour le serveur de développement : php -S localhost:8000 router.php
$p = rawurldecode(parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH));
if (preg_match('#^/(data|sites)(/|$)#', $p) || preg_match('#/(config|router)\.php$#', $p)) { http_response_code(403); exit('403'); }
return false;
