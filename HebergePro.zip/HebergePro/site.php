<?php
// Sert les sites hébergés : site.php/{nom}/{chemin}
require_once 'config.php';

function fail(int $code, string $msg): never {
    http_response_code($code);
    header('Content-Type: text/html; charset=UTF-8');
    echo "<!DOCTYPE html><meta charset='utf-8'><title>$code</title><body style='font-family:sans-serif;text-align:center;padding:90px 20px;color:#333'><h1>$code</h1><p>" . htmlspecialchars($msg) . "</p><p><a href='index.php'>Retour à " . APP_NAME . "</a></p>";
    exit;
}

$info = trim($_SERVER['PATH_INFO'] ?? '', '/');
if ($info === '') fail(404, 'Site introuvable.');
$parts = explode('/', $info, 2);
$name = $parts[0]; $rel = rawurldecode($parts[1] ?? '');

if (!preg_match('/^[a-z0-9-]{1,60}$/', $name)) fail(404, 'Site introuvable.');
if (strpos($_SERVER['PATH_INFO'] ?? '', '/', 1) === false) { header('Location: ' . $_SERVER['SCRIPT_NAME'] . '/' . $name . '/', true, 301); exit; }

$st = getDB()->prepare('SELECT id FROM websites WHERE site_name = :n'); $st->bindValue(':n', $name);
$site = $st->execute()->fetchArray(SQLITE3_ASSOC);
$root = realpath(sitePath($name));
if (!$site || !$root) fail(404, 'Site introuvable.');

if (str_contains($rel, "\0")) fail(400, 'Requête invalide.');
$target = realpath($root . '/' . $rel);
if ($target && is_dir($target)) {
    $found = null;
    foreach (['index.html', 'index.htm'] as $i) if (is_file("$target/$i")) { $found = "$target/$i"; break; }
    $target = $found;
}
// Confinement strict au dossier du site
if (!$target || !is_file($target) || !str_starts_with($target, $root . DIRECTORY_SEPARATOR)) fail(404, 'Page introuvable.');
if (isBlockedFile($target)) fail(403, 'Accès refusé.');

$ext = strtolower(pathinfo($target, PATHINFO_EXTENSION));
$mime = MIME_TYPES[$ext] ?? 'application/octet-stream';

// Compteur de visites : uniquement pour les pages HTML
if (in_array($ext, ['html', 'htm'], true)) {
    $u = getDB()->prepare('UPDATE websites SET views = views + 1 WHERE id = :i'); $u->bindValue(':i', $site['id'], SQLITE3_INTEGER); $u->execute();
}

// Le contenu utilisateur est isolé (origine opaque) : il ne peut pas lire les cookies/session de la plateforme.
header('Content-Security-Policy: sandbox allow-scripts allow-forms allow-popups allow-popups-to-escape-sandbox allow-modals allow-downloads');
header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: no-referrer');
header('Access-Control-Allow-Origin: *');
header('Content-Type: ' . $mime);
header('Content-Length: ' . filesize($target));
header('Cache-Control: public, max-age=60');
readfile($target);
